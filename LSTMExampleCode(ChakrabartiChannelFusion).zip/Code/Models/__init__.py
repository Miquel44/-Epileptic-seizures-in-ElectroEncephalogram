#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 19 01:26:22 2022

@author: Guillermo Torres
"""

